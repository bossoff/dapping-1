

    <script src="<?=base_url();?>/assets/js/jquery-1.12.4.min.js"></script>
    <script src="<?=base_url();?>/assets/js/popper.min.js"></script>
    <script src="<?=base_url();?>/assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url();?>/assets/js/owl.carousel.min.js"></script>
    <script src="<?=base_url();?>/assets/js/swiper.min.js"></script>
    <script src="<?=base_url();?>/assets/js/jquery.counterup.min.js"></script>
    <script src="<?=base_url();?>/assets/js/waypoints.min.js"></script>
    <script src="<?=base_url();?>/assets/js/jquery.sticky.js"></script>
    <script src="<?=base_url();?>/assets/js/webvendor.js"></script>
    <script src="<?=base_url();?>/assets/js/scrolltotop.js"></script>
    <script src="<?=base_url();?>/assets/js/contact-form-script.js"></script>
    <script src="<?=base_url();?>/assets/js/jquery.ajaxchimp.js"></script>
    <script src="<?=base_url();?>/assets/js/wow.min.js"></script>
    <script src="<?=base_url();?>/assets/js/lity.min.js"></script>
    <script src="<?=base_url();?>/assets/js/smooth-scroll.min.js"></script>
    <script src="<?=base_url();?>/assets/js/slicknav-min.js"></script>
    <script src="<?=base_url();?>/assets/js/jquery.barChart.js"></script>
    
    <script src="<?=base_url();?>/assets/js/jquery.barfiller.js"></script>
    <script src="<?=base_url();?>/assets/js/jquery.lineProgressbar.js"></script>
    <script src="<?=base_url();?>/assets/js/main.js"></script>
</body>
</html>

